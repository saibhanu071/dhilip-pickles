# Dhilip Pickles backend API

Base URL: `http://<host>:8081`. All protected endpoints require `Authorization: Bearer <JWT>` returned by `/api/auth/register` or `/api/auth/login`.

## Authentication

- `POST /api/auth/register` – register a customer.
- `POST /api/auth/login` – authenticate a customer and receive a JWT.

Registration always creates the `CUSTOMER` role. Admin users are created only through the environment-controlled bootstrap process; there is no public admin registration endpoint.

## Products

- `GET /api/products` – list products (public).
- `GET /api/products/{id}` – get a product (public).
- `POST /api/products` – create a product (ADMIN).
- `PUT /api/products/{id}` – update a product (ADMIN).
- `DELETE /api/products/{id}` – delete a product (ADMIN).

## Cart (CUSTOMER)

- `POST /api/cart/items?productId=1&quantity=2` – add/update cart quantity.
- `GET /api/cart` – view the authenticated customer's cart.
- `PUT /api/cart/items/{itemId}?quantity=3` – change quantity.
- `DELETE /api/cart/items/{itemId}` – remove an item.

## Customer addresses (CUSTOMER)

- `POST /api/addresses` – create an address. JSON fields: `recipientName`, `mobile` (10-digit Indian mobile), `addressLine`, `city`, `state`, `postalCode` (6 digits), optional `country`, `defaultAddress`.
- `GET /api/addresses` – list the authenticated customer's addresses.
- `PUT /api/addresses/{id}` – update an address owned by the authenticated customer (same JSON fields).
- `DELETE /api/addresses/{id}` – delete an address owned by the authenticated customer.

The API derives customer identity from the JWT; clients cannot provide a customer ID to access another customer's address.

## Orders and COD (CUSTOMER)

- `POST /api/orders` – place an order from the authenticated customer's cart. JSON: `{"addressId":1,"paymentMethod":"COD"}`. `paymentMethod` may be omitted; any non-COD value is rejected. New orders start with `orderStatus=PLACED`, `paymentMethod=COD`, and `paymentStatus=PENDING`.
- `GET /api/orders` – list the authenticated customer's orders.
- `GET /api/orders/{id}` – retrieve an order only if it belongs to the authenticated customer.
- `POST /api/orders/{id}/cancel` – customer cancellation allowed only while status is `PLACED` or `CONFIRMED` and payment is `PENDING`.

Order placement verifies address ownership, validates product availability and stock, snapshots product names/prices, reduces stock, saves the order and clears the cart in one database transaction. Customer cancellation restores reserved stock in the same transaction. No online payment gateway is integrated.

## Admin order management (ADMIN)

- `GET /api/admin/orders` – list all orders.
- `PATCH /api/admin/orders/{id}` – update order and/or payment status. JSON fields: `orderStatus` and/or `paymentStatus`.
- Allowed order statuses: `PLACED`, `CONFIRMED`, `PROCESSING`, `SHIPPED`, `DELIVERED`, `CANCELLED`.
- Allowed COD payment statuses: `PENDING`, `PAID`. Marking `PAID` is allowed only when the order is `DELIVERED` (cash collected). A collected payment cannot be reverted. Delivered and cancelled orders cannot be moved backwards. Cancelling an unpaid order restores stock; paid orders cannot be cancelled through this endpoint.

## Database migrations and deployment

- Flyway migrations live in `src/main/resources/db/migration`.
- Hibernate schema mode is `validate`; Hibernate will not automatically alter production tables.
- `baseline-on-migrate=true` and baseline version `0` allow the first migration to run against an existing, previously Hibernate-managed schema. Migration V1 uses `CREATE TABLE IF NOT EXISTS` so existing customer/product/cart tables and their data are retained while missing application tables are added.
- **Before deploying this version to a real database:** take a verified RDS snapshot/backup, confirm the target database name and credentials, review the generated schema with your DBA, and test the migration against a restored copy first. Do not drop tables or volumes.
- Production secrets are supplied through environment variables: `DB_USERNAME`, `DB_PASSWORD`, `JWT_SECRET`. Keep `ADMIN_BOOTSTRAP_ENABLED=false` except during a controlled first-admin creation; disable it again immediately afterward.

## Verification

Run `./mvnw -B clean verify`. Tests use an isolated H2 database and do not connect to production RDS. Test migrations are disabled for H2 because V1 is written for MySQL; validate the Flyway migration separately against a disposable MySQL instance before production rollout.

API responses currently use entity-shaped JSON. For high-volume production use, add response DTOs, pagination, rate limiting, audit logging, and concurrency/stock reservation controls before launch.
