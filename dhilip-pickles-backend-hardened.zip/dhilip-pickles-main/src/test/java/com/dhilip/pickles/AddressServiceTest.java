package com.dhilip.pickles;

import com.dhilip.pickles.entity.CustomerAddress;
import com.dhilip.pickles.repository.CustomerAddressRepository;
import com.dhilip.pickles.service.AddressService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AddressServiceTest {
 @Mock CustomerAddressRepository repository;
 AddressService service;
 AddressService.AddressRequest valid;
 @BeforeEach void setUp(){service=new AddressService(repository);valid=new AddressService.AddressRequest("Test Customer","9876543210","12 Main Road","Chennai","Tamil Nadu","600001","India",true);}
 @Test void createsAddressForAuthenticatedCustomer(){when(repository.save(any())).thenAnswer(i->i.getArgument(0));CustomerAddress a=service.create(10L,valid);assertEquals(10L,a.getCustomerId());assertEquals("Test Customer",a.getRecipientName());assertTrue(a.isDefaultAddress());verify(repository).findByCustomerIdOrderByDefaultAddressDescIdDesc(10L);}
 @Test void rejectsInvalidMobile(){var bad=new AddressService.AddressRequest("Test","123","Street","City","State","600001","India",false);assertThrows(ResponseStatusException.class,()->service.create(10L,bad));verify(repository,never()).save(any());}
 @Test void rejectsInvalidPostalCode(){var bad=new AddressService.AddressRequest("Test","9876543210","Street","City","State","ABC","India",false);assertThrows(ResponseStatusException.class,()->service.create(10L,bad));}
 @Test void listsOnlyRequestedCustomersAddresses(){when(repository.findByCustomerIdOrderByDefaultAddressDescIdDesc(10L)).thenReturn(List.of(new CustomerAddress()));assertEquals(1,service.list(10L).size());verify(repository).findByCustomerIdOrderByDefaultAddressDescIdDesc(10L);}
 @Test void preventsUpdatingAnotherCustomersAddress(){when(repository.findByIdAndCustomerId(5L,10L)).thenReturn(Optional.empty());assertThrows(ResponseStatusException.class,()->service.update(10L,5L,valid));}
 @Test void preventsDeletingAnotherCustomersAddress(){when(repository.findByIdAndCustomerId(5L,10L)).thenReturn(Optional.empty());assertThrows(ResponseStatusException.class,()->service.delete(10L,5L));verify(repository,never()).delete(any(CustomerAddress.class));}
 @Test void updatesOwnedAddress(){CustomerAddress a=new CustomerAddress();a.setCustomerId(10L);when(repository.findByIdAndCustomerId(5L,10L)).thenReturn(Optional.of(a));when(repository.findByCustomerIdOrderByDefaultAddressDescIdDesc(10L)).thenReturn(List.of(a));CustomerAddress result=service.update(10L,5L,valid);assertEquals("Chennai",result.getCity());assertTrue(result.isDefaultAddress());}
}
