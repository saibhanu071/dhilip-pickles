package com.dhilip.pickles;

import com.dhilip.pickles.entity.*;
import com.dhilip.pickles.repository.*;
import com.dhilip.pickles.service.OrderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderServiceTest {
 @Mock CustomerAddressRepository addresses; @Mock CustomerOrderRepository orders; @Mock CartItemRepository carts; @Mock ProductRepository products; @Mock CustomerRepository customers;
 OrderService service;
 @BeforeEach void setup(){service=new OrderService(addresses,orders,carts,products,customers);}
 @Test void rejectsNonCodPayment(){assertThrows(ResponseStatusException.class,()->service.place(7L,3L,"RAZORPAY"));verifyNoInteractions(addresses,orders,carts,products,customers);}
 @Test void rejectsOrderWhenCartIsEmpty(){CustomerAddress a=new CustomerAddress();when(addresses.findByIdAndCustomerId(3L,7L)).thenReturn(Optional.of(a));Customer c=new Customer();c.setMobile("9876543210");when(customers.findById(7L)).thenReturn(Optional.of(c));when(carts.findByCustomerMobile("9876543210")).thenReturn(List.of());assertThrows(ResponseStatusException.class,()->service.place(7L,3L,"COD"));verify(orders,never()).save(any());}
 @Test void placesCodOrderAndReducesStock(){CustomerAddress a=new CustomerAddress();a.setRecipientName("Test");a.setMobile("9876543210");a.setAddressLine("1 Main Road");a.setCity("Chennai");a.setState("Tamil Nadu");a.setPostalCode("600001");a.setCountry("India");when(addresses.findByIdAndCustomerId(3L,7L)).thenReturn(Optional.of(a));Customer c=new Customer();c.setMobile("9876543210");when(customers.findById(7L)).thenReturn(Optional.of(c));CartItem ci=new CartItem("9876543210",11L,2);when(carts.findByCustomerMobile("9876543210")).thenReturn(List.of(ci));Product p=new Product();p.setId(11L);p.setName("Mango Pickle");p.setPrice(new BigDecimal("150.00"));p.setStockQuantity(5);p.setActive(true);when(products.findById(11L)).thenReturn(Optional.of(p));when(orders.save(any(CustomerOrder.class))).thenAnswer(inv->inv.getArgument(0));CustomerOrder result=service.place(7L,3L,"COD");assertEquals("COD",result.getPaymentMethod());assertEquals("PENDING",result.getPaymentStatus());assertEquals("PLACED",result.getOrderStatus());assertEquals(new BigDecimal("300.00"),result.getTotalAmount());assertEquals(3,p.getStockQuantity());assertEquals(1,result.getItems().size());verify(carts).deleteAll(List.of(ci));}

 @Test void customerCannotReadAnotherCustomersOrder(){when(orders.findByIdAndCustomerId(99L,7L)).thenReturn(Optional.empty());assertThrows(ResponseStatusException.class,()->service.getMine(7L,99L));}
 @Test void customerCannotCancelAnotherCustomersOrder(){when(orders.findByIdAndCustomerId(99L,7L)).thenReturn(Optional.empty());assertThrows(ResponseStatusException.class,()->service.cancelMine(7L,99L));verifyNoInteractions(products);}
 @Test void customerCancellationRestoresStock(){CustomerOrder order=order("PLACED","PENDING");OrderItem item=new OrderItem();item.setProductId(11L);item.setQuantity(2);order.addItem(item);when(orders.findByIdAndCustomerId(5L,7L)).thenReturn(Optional.of(order));Product product=new Product();product.setStockQuantity(3);when(products.findById(11L)).thenReturn(Optional.of(product));CustomerOrder result=service.cancelMine(7L,5L);assertEquals("CANCELLED",result.getOrderStatus());assertEquals(5,product.getStockQuantity());}
 @Test void customerCannotCancelShippedOrder(){CustomerOrder order=order("SHIPPED","PENDING");when(orders.findByIdAndCustomerId(5L,7L)).thenReturn(Optional.of(order));assertThrows(ResponseStatusException.class,()->service.cancelMine(7L,5L));verifyNoInteractions(products);}
 @Test void adminCancellationRestoresStockOnlyOnce(){CustomerOrder order=order("PROCESSING","PENDING");OrderItem item=new OrderItem();item.setProductId(11L);item.setQuantity(2);order.addItem(item);when(orders.findById(5L)).thenReturn(Optional.of(order));Product product=new Product();product.setStockQuantity(3);when(products.findById(11L)).thenReturn(Optional.of(product));service.updateStatus(5L,"CANCELLED",null);assertEquals(5,product.getStockQuantity());assertThrows(ResponseStatusException.class,()->service.updateStatus(5L,"CANCELLED",null));assertEquals(5,product.getStockQuantity());}
 @Test void cannotMarkCodPaidBeforeDelivery(){CustomerOrder order=order("SHIPPED","PENDING");when(orders.findById(5L)).thenReturn(Optional.of(order));assertThrows(ResponseStatusException.class,()->service.updateStatus(5L,null,"PAID"));assertEquals("PENDING",order.getPaymentStatus());}
 @Test void canMarkCodPaidAfterDelivery(){CustomerOrder order=order("DELIVERED","PENDING");when(orders.findById(5L)).thenReturn(Optional.of(order));CustomerOrder updated=service.updateStatus(5L,null,"PAID");assertEquals("PAID",updated.getPaymentStatus());}
 @Test void cannotReverseCollectedPayment(){CustomerOrder order=order("DELIVERED","PAID");when(orders.findById(5L)).thenReturn(Optional.of(order));assertThrows(ResponseStatusException.class,()->service.updateStatus(5L,null,"PENDING"));assertEquals("PAID",order.getPaymentStatus());}
 @Test void cannotCancelDeliveredOrder(){CustomerOrder order=order("DELIVERED","PENDING");when(orders.findById(5L)).thenReturn(Optional.of(order));assertThrows(ResponseStatusException.class,()->service.updateStatus(5L,"CANCELLED",null));verifyNoInteractions(products);}
 private CustomerOrder order(String status,String payment){CustomerOrder o=new CustomerOrder();o.setCustomerId(7L);o.setOrderNumber("DP-TEST0001");o.setTotalAmount(new BigDecimal("100.00"));o.setDeliveryAddress("Test address");o.setOrderStatus(status);o.setPaymentStatus(payment);o.setPaymentMethod("COD");return o;}
}
