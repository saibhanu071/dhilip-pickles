package com.dhilip.pickles.controller;
import com.dhilip.pickles.entity.CustomerOrder;
import com.dhilip.pickles.service.OrderService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/admin/orders")
public class AdminOrderController {
 private final OrderService service;public AdminOrderController(OrderService s){service=s;}
 public record UpdateOrderRequest(String orderStatus,String paymentStatus){}
 @GetMapping public List<CustomerOrder> all(){return service.all();}
 @PatchMapping("/{id}") public CustomerOrder update(@PathVariable Long id,@RequestBody UpdateOrderRequest r){return service.updateStatus(id,r.orderStatus(),r.paymentStatus());}
}
