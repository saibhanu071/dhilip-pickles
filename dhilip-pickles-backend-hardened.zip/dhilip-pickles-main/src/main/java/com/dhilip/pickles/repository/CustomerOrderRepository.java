package com.dhilip.pickles.repository;
import com.dhilip.pickles.entity.CustomerOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface CustomerOrderRepository extends JpaRepository<CustomerOrder,Long> {
 List<CustomerOrder> findByCustomerIdOrderByCreatedAtDesc(Long customerId);
 Optional<CustomerOrder> findByIdAndCustomerId(Long id, Long customerId);
}
