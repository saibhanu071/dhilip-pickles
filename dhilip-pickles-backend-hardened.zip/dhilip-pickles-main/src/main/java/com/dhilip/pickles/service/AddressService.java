package com.dhilip.pickles.service;

import com.dhilip.pickles.entity.CustomerAddress;
import com.dhilip.pickles.repository.CustomerAddressRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@Service
public class AddressService {
 private final CustomerAddressRepository repo;
 public AddressService(CustomerAddressRepository repo){this.repo=repo;}
 public record AddressRequest(String recipientName,String mobile,String addressLine,String city,String state,String postalCode,String country,boolean defaultAddress){}
 @Transactional public CustomerAddress create(Long customerId,AddressRequest r){
  validate(r); if(r.defaultAddress()) repo.findByCustomerIdOrderByDefaultAddressDescIdDesc(customerId).forEach(a->a.setDefaultAddress(false));
  CustomerAddress a=new CustomerAddress(); a.setCustomerId(customerId); a.setRecipientName(r.recipientName().trim()); a.setMobile(r.mobile().trim()); a.setAddressLine(r.addressLine().trim()); a.setCity(r.city().trim()); a.setState(r.state().trim()); a.setPostalCode(r.postalCode().trim()); a.setCountry(r.country()==null||r.country().isBlank()?"India":r.country().trim()); a.setDefaultAddress(r.defaultAddress()); return repo.save(a);
 }
 public List<CustomerAddress> list(Long id){return repo.findByCustomerIdOrderByDefaultAddressDescIdDesc(id);}
 @Transactional public CustomerAddress update(Long customerId,Long id,AddressRequest r){validate(r); CustomerAddress a=repo.findByIdAndCustomerId(id,customerId).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Address not found")); if(r.defaultAddress()) repo.findByCustomerIdOrderByDefaultAddressDescIdDesc(customerId).forEach(x->x.setDefaultAddress(false)); a.setRecipientName(r.recipientName().trim());a.setMobile(r.mobile().trim());a.setAddressLine(r.addressLine().trim());a.setCity(r.city().trim());a.setState(r.state().trim());a.setPostalCode(r.postalCode().trim());a.setCountry(r.country()==null||r.country().isBlank()?"India":r.country().trim());a.setDefaultAddress(r.defaultAddress());return a;}
 public void delete(Long customerId,Long id){CustomerAddress a=repo.findByIdAndCustomerId(id,customerId).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Address not found"));repo.delete(a);}
 private void validate(AddressRequest r){if(r==null||blank(r.recipientName())||blank(r.mobile())||!r.mobile().matches("^[6-9][0-9]{9}$")||blank(r.addressLine())||blank(r.city())||blank(r.state())||blank(r.postalCode())||!r.postalCode().matches("^[0-9]{6}$"))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Valid recipient, 10-digit mobile, address, city, state and 6-digit postal code are required");}
 private boolean blank(String s){return s==null||s.isBlank();}
}
