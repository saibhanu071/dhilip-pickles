package com.dhilip.pickles.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "customer_addresses")
public class CustomerAddress {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private Long customerId;
    @Column(nullable = false) private String recipientName;
    @Column(nullable = false, length = 20) private String mobile;
    @Column(nullable = false, length = 500) private String addressLine;
    @Column(nullable = false) private String city;
    @Column(nullable = false) private String state;
    @Column(nullable = false, length = 10) private String postalCode;
    @Column(nullable = false) private String country = "India";
    @Column(nullable = false) private boolean defaultAddress;
    private LocalDateTime createdAt;
    @PrePersist void created() { createdAt = LocalDateTime.now(); }
    public Long getId(){return id;} public Long getCustomerId(){return customerId;} public void setCustomerId(Long v){customerId=v;}
    public String getRecipientName(){return recipientName;} public void setRecipientName(String v){recipientName=v;}
    public String getMobile(){return mobile;} public void setMobile(String v){mobile=v;}
    public String getAddressLine(){return addressLine;} public void setAddressLine(String v){addressLine=v;}
    public String getCity(){return city;} public void setCity(String v){city=v;}
    public String getState(){return state;} public void setState(String v){state=v;}
    public String getPostalCode(){return postalCode;} public void setPostalCode(String v){postalCode=v;}
    public String getCountry(){return country;} public void setCountry(String v){country=v;}
    public boolean isDefaultAddress(){return defaultAddress;} public void setDefaultAddress(boolean v){defaultAddress=v;}
}
