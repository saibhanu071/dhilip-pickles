package com.dhilip.pickles.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="customer_orders")
public class CustomerOrder {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(nullable=false) private Long customerId;
    @Column(nullable=false, unique=true, length=40) private String orderNumber;
    @Column(nullable=false, precision=12, scale=2) private BigDecimal totalAmount;
    @Column(nullable=false, length=30) private String paymentMethod="COD";
    @Column(nullable=false, length=30) private String paymentStatus="PENDING";
    @Column(nullable=false, length=30) private String orderStatus="PLACED";
    @Column(nullable=false, length=1000) private String deliveryAddress;
    @Column(nullable=false) private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    @OneToMany(mappedBy="order", cascade=CascadeType.ALL, orphanRemoval=true, fetch=FetchType.EAGER)
    private List<OrderItem> items = new ArrayList<>();
    @PrePersist void created(){createdAt=LocalDateTime.now(); updatedAt=createdAt;}
    @PreUpdate void updated(){updatedAt=LocalDateTime.now();}
    public void addItem(OrderItem item){items.add(item);item.setOrder(this);}
    public Long getId(){return id;} public Long getCustomerId(){return customerId;} public void setCustomerId(Long v){customerId=v;}
    public String getOrderNumber(){return orderNumber;} public void setOrderNumber(String v){orderNumber=v;}
    public BigDecimal getTotalAmount(){return totalAmount;} public void setTotalAmount(BigDecimal v){totalAmount=v;}
    public String getPaymentMethod(){return paymentMethod;} public void setPaymentMethod(String v){paymentMethod=v;}
    public String getPaymentStatus(){return paymentStatus;} public void setPaymentStatus(String v){paymentStatus=v;}
    public String getOrderStatus(){return orderStatus;} public void setOrderStatus(String v){orderStatus=v;}
    public String getDeliveryAddress(){return deliveryAddress;} public void setDeliveryAddress(String v){deliveryAddress=v;}
    public LocalDateTime getCreatedAt(){return createdAt;} public LocalDateTime getUpdatedAt(){return updatedAt;}
    public List<OrderItem> getItems(){return items;}
}
