package com.dhilip.pickles.service;

import com.dhilip.pickles.entity.*;
import com.dhilip.pickles.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Service
public class OrderService {
 private final CustomerAddressRepository addressRepo; private final CustomerOrderRepository orderRepo; private final CartItemRepository cartRepo; private final ProductRepository productRepo; private final CustomerRepository customerRepo;
 public OrderService(CustomerAddressRepository a,CustomerOrderRepository o,CartItemRepository c,ProductRepository p,CustomerRepository customers){addressRepo=a;orderRepo=o;cartRepo=c;productRepo=p;customerRepo=customers;}
 @Transactional public CustomerOrder place(Long customerId,Long addressId,String paymentMethod){
  if(paymentMethod!=null&&!paymentMethod.equalsIgnoreCase("COD"))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Only Cash on Delivery (COD) is supported");
  CustomerAddress address=addressRepo.findByIdAndCustomerId(addressId,customerId).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Delivery address not found"));
  List<CartItem> cart=cartRepo.findByCustomerMobile(getMobile(customerId)); if(cart.isEmpty())throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Cart is empty");
  CustomerOrder order=new CustomerOrder();order.setCustomerId(customerId);order.setOrderNumber("DP-"+UUID.randomUUID().toString().substring(0,8).toUpperCase());order.setPaymentMethod("COD");order.setPaymentStatus("PENDING");order.setOrderStatus("PLACED");order.setDeliveryAddress(String.join(", ",address.getRecipientName(),address.getMobile(),address.getAddressLine(),address.getCity(),address.getState(),address.getPostalCode(),address.getCountry()));
  BigDecimal total=BigDecimal.ZERO;
  for(CartItem ci:cart){Product p=productRepo.findById(ci.getProductId()).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Product not found")); if(!Boolean.TRUE.equals(p.getActive())||p.getStockQuantity()<ci.getQuantity())throw new ResponseStatusException(HttpStatus.CONFLICT,"Insufficient stock for product: "+p.getName()); p.setStockQuantity(p.getStockQuantity()-ci.getQuantity()); BigDecimal line=p.getPrice().multiply(BigDecimal.valueOf(ci.getQuantity()));OrderItem oi=new OrderItem();oi.setProductId(p.getId());oi.setProductName(p.getName());oi.setQuantity(ci.getQuantity());oi.setUnitPrice(p.getPrice());oi.setLineTotal(line);order.addItem(oi);total=total.add(line);}
  order.setTotalAmount(total);CustomerOrder saved=orderRepo.save(order);cartRepo.deleteAll(cart);return saved;
 }
 // Customer mobile is the established cart ownership key; retrieve it via a small repository lookup.
 private String getMobile(Long customerId){return customerRepo.findById(customerId).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Customer not found")).getMobile();}
 public List<CustomerOrder> mine(Long id){return orderRepo.findByCustomerIdOrderByCreatedAtDesc(id);}
 public CustomerOrder getMine(Long customerId,Long orderId){return orderRepo.findByIdAndCustomerId(orderId,customerId).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Order not found"));}
 public List<CustomerOrder> all(){return orderRepo.findAll(org.springframework.data.domain.Sort.by(org.springframework.data.domain.Sort.Direction.DESC,"createdAt"));}
 @Transactional public CustomerOrder updateStatus(Long id,String status,String paymentStatus){
  CustomerOrder order=orderRepo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Order not found"));
  String nextStatus=status==null?order.getOrderStatus():status.toUpperCase();
  String nextPayment=paymentStatus==null?order.getPaymentStatus():paymentStatus.toUpperCase();
  if(!List.of("PLACED","CONFIRMED","PROCESSING","SHIPPED","DELIVERED","CANCELLED").contains(nextStatus))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid order status");
  if(!List.of("PENDING","PAID").contains(nextPayment))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"COD payment status must be PENDING or PAID");
  if(order.getOrderStatus().equals("CANCELLED"))throw new ResponseStatusException(HttpStatus.CONFLICT,"Cancelled orders cannot be changed");
  if(order.getOrderStatus().equals("DELIVERED")&&!nextStatus.equals("DELIVERED"))throw new ResponseStatusException(HttpStatus.CONFLICT,"Delivered order status cannot be changed");
  if(order.getPaymentStatus().equals("PAID")&&!nextPayment.equals("PAID"))throw new ResponseStatusException(HttpStatus.CONFLICT,"Collected COD payment cannot be reversed");
  if(nextPayment.equals("PAID")&&(!nextStatus.equals("DELIVERED")||!order.getPaymentMethod().equals("COD")))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"COD can be marked PAID only after delivery and cash collection");
  if(nextStatus.equals("CANCELLED")&&order.getPaymentStatus().equals("PAID"))throw new ResponseStatusException(HttpStatus.CONFLICT,"A paid order cannot be cancelled; process a refund separately");
  if(nextStatus.equals("CANCELLED")&&!order.getOrderStatus().equals("CANCELLED"))restoreStock(order);
  order.setOrderStatus(nextStatus);order.setPaymentStatus(nextPayment);return order;
 }

 @Transactional public CustomerOrder cancelMine(Long customerId,Long orderId){
  CustomerOrder order=orderRepo.findByIdAndCustomerId(orderId,customerId).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Order not found"));
  if(!List.of("PLACED","CONFIRMED").contains(order.getOrderStatus()))throw new ResponseStatusException(HttpStatus.CONFLICT,"Only placed or confirmed orders can be cancelled by the customer");
  if(!"PENDING".equals(order.getPaymentStatus()))throw new ResponseStatusException(HttpStatus.CONFLICT,"Paid orders cannot be cancelled through this endpoint");
  restoreStock(order);order.setOrderStatus("CANCELLED");return order;
 }

 private void restoreStock(CustomerOrder order){
  for(OrderItem item:order.getItems()){
   Product product=productRepo.findById(item.getProductId()).orElseThrow(()->new ResponseStatusException(HttpStatus.CONFLICT,"Cannot restore stock: product "+item.getProductId()+" no longer exists"));
   product.setStockQuantity(product.getStockQuantity()+item.getQuantity());
  }
 }

}
