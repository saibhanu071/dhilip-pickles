package com.dhilip.pickles.controller;
import com.dhilip.pickles.entity.Customer;
import com.dhilip.pickles.entity.CustomerOrder;
import com.dhilip.pickles.repository.CustomerRepository;
import com.dhilip.pickles.service.OrderService;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
@RestController @RequestMapping("/api/orders")
public class OrderController {
 private final OrderService service;private final CustomerRepository customers;
 public OrderController(OrderService s,CustomerRepository c){service=s;customers=c;}
 private Long customerId(Authentication a){return customers.findByEmail(a.getName()).map(Customer::getId).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Customer not found"));}
 public record PlaceOrderRequest(Long addressId,String paymentMethod){}
 @PostMapping public CustomerOrder place(Authentication a,@RequestBody PlaceOrderRequest r){if(r==null||r.addressId()==null)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"addressId is required");return service.place(customerId(a),r.addressId(),r.paymentMethod());}
 @GetMapping public List<CustomerOrder> mine(Authentication a){return service.mine(customerId(a));}
 @PostMapping("/{id}/cancel") public CustomerOrder cancel(Authentication a,@PathVariable Long id){return service.cancelMine(customerId(a),id);}
 @GetMapping("/{id}") public CustomerOrder get(Authentication a,@PathVariable Long id){return service.getMine(customerId(a),id);}
}
