package com.dhilip.pickles.controller;
import com.dhilip.pickles.entity.Customer;
import com.dhilip.pickles.entity.CustomerAddress;
import com.dhilip.pickles.repository.CustomerRepository;
import com.dhilip.pickles.service.AddressService;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
@RestController @RequestMapping("/api/addresses")
public class AddressController {
 private final AddressService service; private final CustomerRepository customers;
 public AddressController(AddressService s,CustomerRepository c){service=s;customers=c;}
 private Long customerId(Authentication a){return customers.findByEmail(a.getName()).map(Customer::getId).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Customer not found"));}
 @PostMapping public CustomerAddress create(Authentication a,@RequestBody AddressService.AddressRequest r){return service.create(customerId(a),r);}
 @GetMapping public List<CustomerAddress> list(Authentication a){return service.list(customerId(a));}
 @PutMapping("/{id}") public CustomerAddress update(Authentication a,@PathVariable Long id,@RequestBody AddressService.AddressRequest r){return service.update(customerId(a),id,r);}
 @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(Authentication a,@PathVariable Long id){service.delete(customerId(a),id);}
}
